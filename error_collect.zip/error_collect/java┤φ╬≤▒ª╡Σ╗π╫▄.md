---
typora-root-url: img
---

# java错误宝典汇总

# 1-MySql相关

## 11-navicat链接mysql8报错

### 111-错误现象

1251-Client does not support authentication  protocol requested by server；如图所示:

 ![](/1616139136049.png)

### 112-问题原因

mysql8的加密方式和以前5.*版本不一样

### 113-解决方案

![](/1616139478427.png)

#### a-以root用户登录mysql

在命令窗口输入mysql -uroot -p 登录进去或者使用mysql自带的客户端命令行窗口点击进去输入密码

#### b-更改加密方式

```mysql
ALTER USER 'root'@'localhost' IDENTIFIED BY 'password' PASSWORD EXPIRE NEVER;
```

#### c-更改密码

```mysql
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY '新密码';
```

#### d-刷新

```mysql
FLUSH PRIVILEGES;
```

## 12-使用mysql8报时区错误

### 121-错误现象

```java
The server time zone value '�й���׼ʱ��' 
```

### 122-问题原因

升级后需要在连接数据库url加上时区

### 123-解决方案

```java
url=jdbc:mysql://localhost:3306/slsaledb?serverTimezone=UTC
```

